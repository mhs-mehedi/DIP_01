clc;
clear all;
close all;
 
% Parameters
num_symbols = 1e5; % Number of symbols
snr_db = 0:2:20; % Range of SNR values in dB
 
% PSK orders to be tested
psk_orders = [2, 4, 8];
 
% Initialize BER arrays
ber_results = zeros(length(psk_orders), length(snr_db));
 
% BER calculation for each PSK order and SNR value
for i = 1:length(psk_orders)
    psk_order = psk_orders(i);
 
    for j = 1:length(snr_db)
        % Generate random symbols
        data_symbols = randi([0, psk_order-1], 1, num_symbols);
        
        % Modulate symbols to generate signal
        modulated_signal = pskmod(data_symbols, psk_order);
        
        % Add AWGN to the signal
        snr_linear = 10^(snr_db(j)/10);
        received_signal = awgn(modulated_signal, snr_db(j), 'measured');
        
        % Demodulate received signal
        demodulated_symbols = pskdemod(received_signal, psk_order);
        
        % Calculate BER
        ber_results(i, j) = sum(data_symbols ~= demodulated_symbols) / num_symbols;
    end
end
 
% Plot BER vs. SNR
figure;
semilogy(snr_db, ber_results(1, :), 'o-', 'DisplayName', 'BPSK');
hold on;
 
for i = 2:length(psk_orders)
    semilogy(snr_db, ber_results(i, :), 'o-', 'DisplayName', sprintf('%d-PSK', psk_orders(i)));
end
 
title('BER vs. SNR for Various PSK Schemes');
xlabel('SNR (dB)');
ylabel('Bit Error Rate (BER)');
legend('Location', 'best');
grid on;
hold off;