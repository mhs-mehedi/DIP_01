clc;
clear;
close all;

% Given binary sequence
binary_seq = [1 0 1 1 0 0 1 0 0 1];
numBits = length(binary_seq);

% Define parameters
Eb = 1; % Energy per bit
Tb = 1; % Bit duration
fc = 2; % Carrier frequency
fs = 100; % Sampling frequency
t = linspace(0, Tb, fs); % Time vector for each bit

% Generate Polar NRZ signal
polar_NZR = 2 * binary_seq - 1;

% Modulated BPSK signal
bpsk_signal = [];
for n = 1:numBits
    bpsk_signal = [bpsk_signal polar_NZR(n) * sqrt(2*Eb/Tb) * cos(2*pi*fc*t)];
end

% Add AWGN noise
SNR_dB = 1; % SNR = 1 dB
bpsk_noisy_signal = awgn(bpsk_signal, SNR_dB, 'measured');

% Receiver: Coherent demodulation
demodulated_bits = [];
for n = 1:numBits
    % Correlation with carrier
    correlation = sum(bpsk_noisy_signal((n-1)*fs+1 : n*fs) .* cos(2*pi*fc*t));
    
    % Decision threshold
    if correlation > 0
        demodulated_bits = [demodulated_bits 1];
    else
        demodulated_bits = [demodulated_bits 0];
    end
end

% Calculate number of erroneous bits
num_errors = sum(binary_seq ~= demodulated_bits);
disp(['Number of bit errors: ', num2str(num_errors)]);

% Plot results
figure;
subplot(3,1,1);
stairs(binary_seq, 'LineWidth', 2);
ylim([-1.5 1.5]);
title('Polar NRZ Input Binary Sequence');
grid on;

subplot(3,1,2);
plot(bpsk_noisy_signal, 'r');
title('Received BPSK Signal in AWGN Channel');
grid on;

subplot(3,1,3);
stairs(demodulated_bits, 'LineWidth', 2);
ylim([-1.5 1.5]);
title('Detected Binary Sequence After Demodulation');
grid on;
