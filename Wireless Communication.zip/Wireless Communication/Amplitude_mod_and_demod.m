fc=100;
fm=10;
Ac=1;
Am=1;
Fs=1000;
t=0:0.001:1;

message_signal=Am*sin(2*pi*fm*t);
carrier_signal=Ac*sin(2*pi*fc*t);

k=Am/Ac;
modulated_signal=(1+k*message_signal).*carrier_signal;

snr_db=1;
signal_power=mean(modulated_signal.^2);
noise_power=signal_power/(10^(snr_db/10));
noise=sqrt(noise_power/2)*randn(size(modulated_signal));
noisy_modulated_signal=noise+modulated_signal;

demodulated_signal=2*modulated_signal.*carrier_signal;
demodulated_signal=lowpass(demodulated_signal,10,Fs)


figure(1)
subplot(221)
plot(t,message_signal)
title('Message Signal')

subplot(222)
plot(t,carrier_signal)
title('Carrier signal')

subplot(223)
plot(t,noisy_modulated_signal)
title('Modulated Signal')

subplot(224)
plot(t,demodulated_signal)
title('Demodulated Signal')

figure(2)
plot(t,noisy_modulated_signal)