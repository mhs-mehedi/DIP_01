clc;
clear all;
close all;

% Parameters
num_symbols = 1e5; % Number of symbols
SNR_dB = 0:2:20; % Range of SNR values in dB

% PSK orders to be tested
M_values = [2, 4, 8];

% Initialize BER array
BER = zeros(length(M_values), length(SNR_dB));

% BER calculation for each PSK order and SNR value
for i = 1:length(M_values)
    M = M_values(i);

    for j = 1:length(SNR_dB)
        % Generate random symbols
        data_symbols = randi([0, M-1], 1, num_symbols);

        % Modulate symbols using PSK
        modulated_signal = pskmod(data_symbols, M, pi/M);

        % Add AWGN to the signal
        received_signal = awgn(modulated_signal, SNR_dB(j), 'measured');

        % Demodulate received signal
        demodulated_symbols = pskdemod(received_signal, M, pi/M);

        % Calculate BER
        BER(i, j) = sum(data_symbols ~= demodulated_symbols) / num_symbols;
    end
end

% Plot BER vs SNR
figure;
semilogy(SNR_dB, BER(1,:), 'bo-', 'LineWidth', 2); % BPSK (M=2)
hold on;
semilogy(SNR_dB, BER(2,:), 'ro-', 'LineWidth', 2); % QPSK (M=4)
semilogy(SNR_dB, BER(3,:), 'go-', 'LineWidth', 2); % 8-PSK (M=8)
grid on;

xlabel('SNR (dB)');
ylabel('Bit Error Rate (BER)');
title('BER vs SNR for Different PSK Modulation Orders');
legend('BPSK (M=2)', 'QPSK (M=4)', '8-PSK (M=8)');
hold off;
