M=8;
bps=log2(M);

input_text='Information and communication engineering'
symbols=double(input_text)

symb